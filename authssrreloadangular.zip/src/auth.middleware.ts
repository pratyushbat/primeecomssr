import {  NextFunction, Request, Response } from 'express';
import jwt from "jsonwebtoken";

export function authMiddleware(req: Request | any, res:Response, next: NextFunction) {
  const token = req.cookies?.jwtAutToken;

  if (!token) {
    req.user = null;
    return next();
  }

  try {
    req.user = jwt.verify(token, "jwt_key" );
    console.log('req.user in middleware',req.user)
  } catch {
    req.user = null;
  }

  next();
}